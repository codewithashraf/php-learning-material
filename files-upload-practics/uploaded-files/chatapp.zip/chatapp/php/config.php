<?php 
    $conn = mysqli_connect("localhost", "root", "", "chatapp_db") 
    or die('connection failed');
?>