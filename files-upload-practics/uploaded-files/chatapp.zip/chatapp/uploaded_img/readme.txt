 please don't delete the default-avatar.png it
 is there incase if user did not upload a image